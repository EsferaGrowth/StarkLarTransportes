# IMAP Bridge — Stark Lar Transportes

Microserviço Node.js que conecta no IMAP da Hostinger a cada 5 min, lê e-mails novos e envia para o webhook do Lovable.

## Deploy no Railway (recomendado)

1. Crie conta gratuita em https://railway.app
2. Clique em **New Project → Deploy from GitHub repo** (ou **Empty Project → Deploy from local**)
3. Faça upload desta pasta `imap-microservice/` (ou suba para um repo GitHub e conecte)
4. Em **Variables**, adicione:
   - `IMAP_USER` — seu e-mail Hostinger completo
   - `IMAP_PASSWORD` — senha do e-mail (NÃO a senha da conta Hostinger)
   - `WEBHOOK_URL` — `https://enbbxcvtnxtyifyzghsr.supabase.co/functions/v1/imap-webhook-receiver`
   - `WEBHOOK_SECRET` — o mesmo valor que você cadastrou em `IMAP_WEBHOOK_SECRET` no Lovable
   - (opcional) `POLL_INTERVAL_MS=300000`
5. Railway detecta o `package.json` e roda `npm start` automaticamente
6. Acompanhe os **Logs** — você verá `Mailbox: X msgs, uidNext=...` a cada 5 min

## Deploy no Render (alternativa)

1. https://render.com → **New → Background Worker**
2. Conecte um repo GitHub com esta pasta
3. Build command: `npm install`  |  Start command: `npm start`
4. Adicione as mesmas variáveis acima

## Teste local

```bash
cp .env.example .env
# edite .env com suas credenciais
npm install
node --env-file=.env index.js
```

## Segurança

- A senha IMAP **só existe no Railway/Render** — nunca foi enviada ao Lovable nem ao chat
- O webhook valida o `x-webhook-secret` em cada request — sem ele, retorna 401
- E-mails são deduplicados pelo `message_id` no banco
