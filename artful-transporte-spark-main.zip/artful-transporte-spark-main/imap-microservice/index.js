// IMAP -> Webhook bridge for Stark Lar Transportes
// Polls Hostinger IMAP every POLL_INTERVAL_MS, forwards new emails to the
// Lovable edge function `imap-webhook-receiver`, and tracks the last seen UID.

import { ImapFlow } from "imapflow";
import { simpleParser } from "mailparser";
import fs from "fs";
import path from "path";

const {
  IMAP_HOST = "imap.hostinger.com",
  IMAP_PORT = "993",
  IMAP_USER,
  IMAP_PASSWORD,
  IMAP_MAILBOX = "INBOX",
  WEBHOOK_URL,
  WEBHOOK_SECRET,
  POLL_INTERVAL_MS = "300000", // 5 min
  STATE_FILE = "/tmp/imap-state.json",
} = process.env;

if (!IMAP_USER || !IMAP_PASSWORD || !WEBHOOK_URL || !WEBHOOK_SECRET) {
  console.error("Missing required env vars: IMAP_USER, IMAP_PASSWORD, WEBHOOK_URL, WEBHOOK_SECRET");
  process.exit(1);
}

function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); }
  catch { return { lastUid: 0 }; }
}
function saveState(state) {
  try { fs.writeFileSync(STATE_FILE, JSON.stringify(state)); }
  catch (e) { console.error("Could not persist state:", e.message); }
}

async function postToWebhook(emails) {
  const res = await fetch(WEBHOOK_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-webhook-secret": WEBHOOK_SECRET },
    body: JSON.stringify({ emails }),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Webhook ${res.status}: ${text}`);
  return text;
}

async function pollOnce() {
  const state = loadState();
  const client = new ImapFlow({
    host: IMAP_HOST,
    port: Number(IMAP_PORT),
    secure: true,
    auth: { user: IMAP_USER, pass: IMAP_PASSWORD },
    logger: false,
  });
  await client.connect();
  const lock = await client.getMailboxLock(IMAP_MAILBOX);
  try {
    const status = await client.status(IMAP_MAILBOX, { uidNext: true, messages: true });
    console.log(`[${new Date().toISOString()}] Mailbox: ${status.messages} msgs, uidNext=${status.uidNext}, lastSeen=${state.lastUid}`);

    const range = state.lastUid > 0 ? `${state.lastUid + 1}:*` : `${Math.max(1, status.uidNext - 20)}:*`;
    const emails = [];
    let maxUid = state.lastUid;

    for await (const msg of client.fetch(range, { uid: true, envelope: true, source: true }, { uid: true })) {
      if (msg.uid <= state.lastUid) continue;
      try {
        const parsed = await simpleParser(msg.source);
        emails.push({
          message_id: parsed.messageId || `uid-${msg.uid}-${IMAP_USER}`,
          from_email: parsed.from?.value?.[0]?.address || "unknown@unknown",
          from_name: parsed.from?.value?.[0]?.name || null,
          to_email: parsed.to?.value?.[0]?.address || IMAP_USER,
          subject: parsed.subject || "(sem assunto)",
          body_text: parsed.text || null,
          body_html: parsed.html || null,
          received_at: (parsed.date || new Date()).toISOString(),
          raw_headers: null,
        });
      } catch (e) {
        console.error(`Failed to parse uid ${msg.uid}:`, e.message);
      }
      if (msg.uid > maxUid) maxUid = msg.uid;
    }

    if (emails.length > 0) {
      console.log(`Forwarding ${emails.length} new emails to webhook...`);
      const result = await postToWebhook(emails);
      console.log("Webhook response:", result);
      saveState({ lastUid: maxUid });
    } else {
      console.log("No new emails.");
      if (maxUid > state.lastUid) saveState({ lastUid: maxUid });
    }
  } finally {
    lock.release();
    await client.logout();
  }
}

async function loop() {
  console.log(`Starting IMAP bridge (interval: ${POLL_INTERVAL_MS}ms)`);
  while (true) {
    try { await pollOnce(); }
    catch (e) { console.error("Poll error:", e.message); }
    await new Promise(r => setTimeout(r, Number(POLL_INTERVAL_MS)));
  }
}
loop();
