# Project Memory

## Core
Stark Lar Transportes — site corporativo. Tema BRANCO/claro. Verde escuro + amarelo/dourado (cores da logo). Montserrat headings, Inter body.
Dados: CNPJ 26.731.236/0001-58, Jaguaruna-SC, (48) 3660-0313.

## Memories
- [Brand colors](mem://design/colors) — Light theme, green primary, gold accent, white background
- [Company data](mem://features/company-data) — CNPJ, endereço, emails, parceiros comerciais
