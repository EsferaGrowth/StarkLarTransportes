---
name: Brand colors - Light theme
description: White background light theme with green primary and gold accent
type: design
---
Light/white theme. Background white (#FFFFFF), foreground dark (#1a1f2e).
Primary green: 145 60% 28%. Accent gold: 45 90% 50%.
Cards: light gray (210 20% 97%). Borders: 220 13% 88%.
Gold gradients use text-white (not accent-foreground) for contrast.
