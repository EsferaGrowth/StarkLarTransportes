import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * Subscribes to realtime changes on inbox_emails and kanban tables.
 * Calls the provided refresh callbacks when changes occur.
 */
export const useDashboardRealtime = ({
  enabled,
  onInboxChange,
  onKanbanChange,
}: {
  enabled: boolean;
  onInboxChange: () => void;
  onKanbanChange: () => void;
}) => {
  useEffect(() => {
    if (!enabled) return;
    const channel = supabase
      .channel("inbox-changes")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "inbox_emails" },
        () => onInboxChange(),
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "inbox_emails" },
        () => onInboxChange(),
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [enabled, onInboxChange]);

  useEffect(() => {
    if (!enabled) return;
    const channel = supabase
      .channel("kanban-changes")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "kanban_tasks" },
        () => onKanbanChange(),
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "kanban_columns" },
        () => onKanbanChange(),
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [enabled, onKanbanChange]);
};
