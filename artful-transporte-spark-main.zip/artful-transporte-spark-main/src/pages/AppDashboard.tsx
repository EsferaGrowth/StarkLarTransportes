import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useDashboardRealtime } from "@/hooks/useDashboardRealtime";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Inbox, KanbanSquare } from "lucide-react";
import { toast } from "sonner";
import { InboxEmail, GeneratedTaskDraft } from "@/components/dashboard/InboxList";
import { KanbanColumn, KanbanTask } from "@/components/dashboard/KanbanBoard";
import { TaskForm } from "@/components/dashboard/TaskForm";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { InboxTab } from "@/components/dashboard/InboxTab";
import { KanbanTab } from "@/components/dashboard/KanbanTab";

const AppDashboard = () => {
  const navigate = useNavigate();
  const { user, roles, loading: authLoading } = useAuth();
  const isAdmin = roles.includes("admin");
  const hasAccess = roles.includes("admin") || roles.includes("member");

  const [emails, setEmails] = useState<InboxEmail[]>([]);
  const [emailsLoading, setEmailsLoading] = useState(true);
  const [selectedEmail, setSelectedEmail] = useState<InboxEmail | null>(null);

  const [columns, setColumns] = useState<KanbanColumn[]>([]);
  const [tasks, setTasks] = useState<KanbanTask[]>([]);

  const [taskFormOpen, setTaskFormOpen] = useState(false);
  const [taskFormDraft, setTaskFormDraft] = useState<GeneratedTaskDraft | null>(null);
  const [taskFormColumn, setTaskFormColumn] = useState<string | undefined>(undefined);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/app/login");
    } else if (!authLoading && user && roles.length > 0 && !hasAccess) {
      toast.error("Você não tem acesso ao sistema.");
      supabase.auth.signOut();
      navigate("/app/login");
    }
  }, [authLoading, user, roles, hasAccess, navigate]);

  const loadEmails = useCallback(async () => {
    setEmailsLoading(true);
    const { data, error } = await supabase
      .from("inbox_emails")
      .select("id, message_id, from_email, from_name, subject, body_text, received_at, is_read, has_task")
      .order("received_at", { ascending: false })
      .limit(200);
    if (error) {
      toast.error("Erro ao carregar e-mails");
    } else {
      setEmails(data ?? []);
    }
    setEmailsLoading(false);
  }, []);

  const loadKanban = useCallback(async () => {
    const [colsRes, tasksRes] = await Promise.all([
      supabase.from("kanban_columns").select("*").order("position"),
      supabase.from("kanban_tasks").select("*").order("position"),
    ]);
    if (colsRes.data) setColumns(colsRes.data);
    if (tasksRes.data) setTasks(tasksRes.data as KanbanTask[]);
  }, []);

  useEffect(() => {
    if (hasAccess) {
      loadEmails();
      loadKanban();
    }
  }, [hasAccess, loadEmails, loadKanban]);

  useDashboardRealtime({
    enabled: hasAccess,
    onInboxChange: loadEmails,
    onKanbanChange: loadKanban,
  });

  const handleSelectEmail = async (email: InboxEmail) => {
    setSelectedEmail(email);
    if (!email.is_read) {
      const { error } = await supabase
        .from("inbox_emails")
        .update({ is_read: true })
        .eq("id", email.id);
      if (!error) {
        setEmails((prev) => prev.map((e) => e.id === email.id ? { ...e, is_read: true } : e));
      }
    }
  };

  const handleTaskGenerated = (draft: GeneratedTaskDraft) => {
    setTaskFormDraft(draft);
    setTaskFormColumn(undefined);
    setTaskFormOpen(true);
  };

  const handleAddTask = (columnId: string) => {
    setTaskFormDraft(null);
    setTaskFormColumn(columnId);
    setTaskFormOpen(true);
  };

  const saveTask = async (data: {
    title: string;
    description: string;
    priority: "low" | "medium" | "high" | "urgent";
    column_id: string;
    source_email_id?: string | null;
    ai_generated: boolean;
  }) => {
    if (!user) return;
    const { error } = await supabase.from("kanban_tasks").insert({
      ...data,
      created_by: user.id,
    });
    if (error) {
      toast.error("Erro ao salvar tarefa");
      throw error;
    }
    toast.success("Tarefa criada");
    if (data.source_email_id) {
      await supabase
        .from("inbox_emails")
        .update({ has_task: true })
        .eq("id", data.source_email_id);
    }
    loadKanban();
    loadEmails();
  };

  if (authLoading) {
    return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Carregando...</div>;
  }

  if (!user || !hasAccess) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <DashboardHeader email={user.email} isAdmin={isAdmin} />

      <main className="flex-1 overflow-hidden">
        <Tabs defaultValue="inbox" className="h-full flex flex-col">
          <TabsList className="mx-4 mt-3 self-start">
            <TabsTrigger value="inbox"><Inbox className="w-4 h-4 mr-2" /> Caixa de entrada</TabsTrigger>
            <TabsTrigger value="kanban"><KanbanSquare className="w-4 h-4 mr-2" /> Kanban</TabsTrigger>
          </TabsList>

          <TabsContent value="inbox" className="flex-1 overflow-hidden mt-3">
            <InboxTab
              emails={emails}
              selectedEmail={selectedEmail}
              loading={emailsLoading}
              onSelect={handleSelectEmail}
              onTaskGenerated={handleTaskGenerated}
            />
          </TabsContent>

          <TabsContent value="kanban" className="flex-1 overflow-hidden mt-3">
            <KanbanTab
              columns={columns}
              tasks={tasks}
              currentUserId={user.id}
              isAdmin={isAdmin}
              onTasksChange={loadKanban}
              onAddTask={handleAddTask}
            />
          </TabsContent>
        </Tabs>
      </main>

      <TaskForm
        open={taskFormOpen}
        onClose={() => setTaskFormOpen(false)}
        onSave={saveTask}
        columns={columns}
        initialColumnId={taskFormColumn}
        draft={taskFormDraft}
      />
    </div>
  );
};

export default AppDashboard;
