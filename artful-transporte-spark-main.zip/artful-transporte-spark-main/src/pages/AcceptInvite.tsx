import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Eye, EyeOff, UserPlus } from "lucide-react";
import { toast } from "sonner";
import logoImg from "@/assets/logo-starklar-transparent.png";

const AcceptInvite = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token") ?? "";
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleAccept = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast.error("As senhas não coincidem.");
      return;
    }
    if (password.length < 8) {
      toast.error("A senha deve ter pelo menos 8 caracteres.");
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("accept-invite", {
        body: { token, password },
      });
      if (error) throw error;
      if (!data?.success) throw new Error(data?.error ?? "Erro ao aceitar convite");

      // Auto sign-in
      const { error: signInErr } = await supabase.auth.signInWithPassword({
        email: data.email,
        password,
      });
      if (signInErr) throw signInErr;

      toast.success("Conta criada! Bem-vindo.");
      navigate("/app");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro ao aceitar convite";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  if (!token) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="text-center">
          <p className="text-destructive">Link de convite inválido.</p>
          <a href="/" className="text-primary text-sm hover:underline mt-4 inline-block">← Voltar ao site</a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <a href="/">
            <img src={logoImg} alt="Stark Lar" className="h-14 w-auto mx-auto mb-4" />
          </a>
          <h1 className="text-2xl font-heading font-bold">Aceitar Convite</h1>
          <p className="text-sm text-muted-foreground mt-1">Crie sua senha para acessar o sistema</p>
        </div>

        <form onSubmit={handleAccept} className="bg-card border border-border rounded-xl p-6 space-y-4 shadow-sm">
          <div>
            <label htmlFor="pw" className="text-sm font-medium mb-1 block">Senha (mín. 8 caracteres)</label>
            <div className="relative">
              <input
                id="pw"
                type={showPassword ? "text" : "password"}
                required
                minLength={8}
                maxLength={128}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-background border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 text-sm pr-12"
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          <div>
            <label htmlFor="cpw" className="text-sm font-medium mb-1 block">Confirmar senha</label>
            <input
              id="cpw"
              type={showPassword ? "text" : "password"}
              required
              minLength={8}
              maxLength={128}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-lg bg-background border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 text-sm"
              placeholder="••••••••"
            />
          </div>
          <Button type="submit" disabled={loading} className="w-full bg-gradient-brand text-white font-semibold">
            <UserPlus className="w-4 h-4 mr-2" />
            {loading ? "Criando conta..." : "Criar conta e entrar"}
          </Button>
        </form>
      </div>
    </div>
  );
};

export default AcceptInvite;
