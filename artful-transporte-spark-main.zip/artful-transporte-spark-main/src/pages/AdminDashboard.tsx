import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { LogOut, Mail, Phone, Clock, CheckCircle, Circle, User, Users, KanbanSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import logoImg from "@/assets/logo-starklar-transparent.png";
import { InvitationsManager } from "@/components/admin/InvitationsManager";

interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  message: string;
  read: boolean;
  created_at: string;
}

const AdminDashboard = () => {
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { navigate("/admin"); return; }
      const { data: roles } = await supabase
        .from("user_roles").select("role").eq("user_id", session.user.id).eq("role", "admin");
      if (!roles || roles.length === 0) {
        await supabase.auth.signOut();
        navigate("/admin");
        return;
      }
      fetchMessages();
    };
    checkAuth();
  }, [navigate]);

  const fetchMessages = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("contact_messages").select("*").order("created_at", { ascending: false });
    if (error) toast.error("Erro ao carregar mensagens.");
    else setMessages(data || []);
    setLoading(false);
  };

  const toggleRead = async (id: string, currentRead: boolean) => {
    const { error } = await supabase
      .from("contact_messages").update({ read: !currentRead }).eq("id", id);
    if (!error) setMessages(msgs => msgs.map(m => m.id === id ? { ...m, read: !currentRead } : m));
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/admin");
  };

  const selected = messages.find(m => m.id === selectedId);
  const unreadCount = messages.filter(m => !m.read).length;

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border sticky top-0 z-10">
        <div className="container mx-auto px-4 flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <a href="/"><img src={logoImg} alt="Stark Lar" className="h-8 w-auto" /></a>
            <span className="text-sm font-heading font-semibold text-muted-foreground">Dashboard Admin</span>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={() => navigate("/app")}>
              <KanbanSquare className="w-4 h-4 mr-1" /> Painel
            </Button>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-1" /> Sair
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <Tabs defaultValue="messages">
          <TabsList>
            <TabsTrigger value="messages">
              <Mail className="w-4 h-4 mr-2" /> Mensagens {unreadCount > 0 && <span className="ml-1 text-primary">({unreadCount})</span>}
            </TabsTrigger>
            <TabsTrigger value="invitations">
              <Users className="w-4 h-4 mr-2" /> Convites
            </TabsTrigger>
          </TabsList>

          <TabsContent value="messages" className="mt-6">
            {loading ? (
              <div className="text-center py-20 text-muted-foreground">Carregando...</div>
            ) : messages.length === 0 ? (
              <div className="text-center py-20 text-muted-foreground">
                <Mail className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>Nenhuma mensagem recebida.</p>
              </div>
            ) : (
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1 space-y-2 max-h-[calc(100vh-220px)] overflow-y-auto">
                  {messages.map((msg) => (
                    <button
                      key={msg.id}
                      onClick={() => { setSelectedId(msg.id); if (!msg.read) toggleRead(msg.id, false); }}
                      className={`w-full text-left p-4 rounded-lg border transition-all ${
                        selectedId === msg.id ? "border-primary bg-primary/5" : "border-border bg-card hover:border-primary/30"
                      } ${!msg.read ? "border-l-4 border-l-accent" : ""}`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-semibold truncate">{msg.name}</span>
                        {msg.read ? <CheckCircle className="w-4 h-4 text-primary shrink-0" /> : <Circle className="w-4 h-4 text-accent shrink-0" />}
                      </div>
                      <p className="text-xs text-muted-foreground truncate">{msg.message}</p>
                      <p className="text-[10px] text-muted-foreground mt-1">
                        {new Date(msg.created_at).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </button>
                  ))}
                </div>
                <div className="lg:col-span-2">
                  {selected ? (
                    <div className="bg-card border border-border rounded-xl p-6">
                      <div className="flex items-center justify-between mb-6">
                        <h2 className="text-xl font-heading font-bold">{selected.name}</h2>
                        <Button variant="outline" size="sm" onClick={() => toggleRead(selected.id, selected.read)}>
                          {selected.read ? "Marcar não lida" : "Marcar como lida"}
                        </Button>
                      </div>
                      <div className="space-y-3 mb-6">
                        <div className="flex items-center gap-2 text-sm">
                          <Mail className="w-4 h-4 text-primary" />
                          <a href={`mailto:${selected.email}`} className="hover:text-primary">{selected.email}</a>
                        </div>
                        {selected.phone && (
                          <div className="flex items-center gap-2 text-sm">
                            <Phone className="w-4 h-4 text-primary" />
                            <a href={`tel:${selected.phone}`} className="hover:text-primary">{selected.phone}</a>
                          </div>
                        )}
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          {new Date(selected.created_at).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}
                        </div>
                      </div>
                      <div className="bg-secondary/50 rounded-lg p-4">
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{selected.message}</p>
                      </div>
                      <div className="mt-4 flex gap-2">
                        <Button asChild size="sm" className="bg-gradient-brand text-white">
                          <a href={`https://wa.me/${selected.phone?.replace(/\D/g, "") || "554836600313"}?text=${encodeURIComponent(`Olá ${selected.name}, recebemos sua mensagem!`)}`} target="_blank" rel="noopener noreferrer">
                            Responder via WhatsApp
                          </a>
                        </Button>
                        <Button asChild variant="outline" size="sm"><a href={`mailto:${selected.email}`}>Responder por Email</a></Button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-20 text-muted-foreground border border-border rounded-xl bg-card">
                      <User className="w-12 h-12 mx-auto mb-3 opacity-30" />
                      <p>Selecione uma mensagem para visualizar</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="invitations" className="mt-6">
            <InvitationsManager />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;
