import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import About from "@/components/About";
import Structure from "@/components/Structure";
import Differentials from "@/components/Differentials";
import Partners from "@/components/Partners";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";

const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <Hero />
      <Services />
      <About />
      <Structure />
      <Differentials />
      <Partners />
      <Contact />
      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default Index;
