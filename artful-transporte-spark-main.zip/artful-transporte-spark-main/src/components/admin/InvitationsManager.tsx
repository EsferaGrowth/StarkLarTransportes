import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { UserPlus, Copy, Trash2, Check } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface Invitation {
  id: string;
  email: string;
  token: string;
  used: boolean;
  used_at: string | null;
  expires_at: string;
  created_at: string;
}

export const InvitationsManager = () => {
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState("");
  const [creating, setCreating] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("user_invitations")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) {
      toast.error("Erro ao carregar convites");
    } else {
      setInvitations(data ?? []);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setCreating(true);
    try {
      const { data, error } = await supabase.functions.invoke("invite-user", {
        body: { email: email.trim() },
      });
      if (error) throw error;
      if (!data?.success) throw new Error(data?.error ?? "Erro ao criar convite");

      // Auto-copy link
      await navigator.clipboard.writeText(data.invite_link);
      toast.success("Convite criado e link copiado!");
      setEmail("");
      load();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro ao criar convite";
      toast.error(msg);
    } finally {
      setCreating(false);
    }
  };

  const copyLink = async (inv: Invitation) => {
    const link = `${window.location.origin}/aceitar-convite?token=${inv.token}`;
    await navigator.clipboard.writeText(link);
    setCopiedId(inv.id);
    toast.success("Link copiado");
    setTimeout(() => setCopiedId(null), 2000);
  };

  const remove = async (id: string) => {
    if (!confirm("Apagar este convite?")) return;
    const { error } = await supabase.from("user_invitations").delete().eq("id", id);
    if (error) toast.error("Erro ao apagar");
    else { toast.success("Convite removido"); load(); }
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleCreate} className="bg-card border border-border rounded-lg p-4 flex gap-2">
        <input
          type="email"
          required
          maxLength={255}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="email@exemplo.com"
          className="flex-1 px-3 py-2 rounded-md bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
        />
        <Button type="submit" disabled={creating} className="bg-gradient-brand text-white">
          <UserPlus className="w-4 h-4 mr-1" /> {creating ? "Criando..." : "Convidar"}
        </Button>
      </form>

      {loading ? (
        <p className="text-center text-muted-foreground py-8 text-sm">Carregando...</p>
      ) : invitations.length === 0 ? (
        <p className="text-center text-muted-foreground py-8 text-sm">Nenhum convite enviado.</p>
      ) : (
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
              <tr>
                <th className="text-left p-3">Email</th>
                <th className="text-left p-3">Status</th>
                <th className="text-left p-3">Expira</th>
                <th className="text-right p-3">Ações</th>
              </tr>
            </thead>
            <tbody>
              {invitations.map((inv) => {
                const expired = new Date(inv.expires_at) < new Date();
                return (
                  <tr key={inv.id} className="border-t border-border">
                    <td className="p-3 font-medium">{inv.email}</td>
                    <td className="p-3">
                      {inv.used ? (
                        <span className="text-xs px-2 py-0.5 rounded bg-primary/10 text-primary">
                          Aceito
                        </span>
                      ) : expired ? (
                        <span className="text-xs px-2 py-0.5 rounded bg-destructive/10 text-destructive">
                          Expirado
                        </span>
                      ) : (
                        <span className="text-xs px-2 py-0.5 rounded bg-secondary text-secondary-foreground">
                          Pendente
                        </span>
                      )}
                    </td>
                    <td className="p-3 text-xs text-muted-foreground">
                      {format(new Date(inv.expires_at), "dd/MM/yyyy", { locale: ptBR })}
                    </td>
                    <td className="p-3 text-right space-x-1">
                      {!inv.used && !expired && (
                        <Button size="sm" variant="ghost" onClick={() => copyLink(inv)}>
                          {copiedId === inv.id ? (
                            <Check className="w-3.5 h-3.5" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </Button>
                      )}
                      <Button size="sm" variant="ghost" onClick={() => remove(inv.id)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <p className="text-xs text-muted-foreground">
        💡 Copie o link e envie ao convidado por e-mail, WhatsApp ou outro canal. O link expira em 7 dias.
      </p>
    </div>
  );
};
