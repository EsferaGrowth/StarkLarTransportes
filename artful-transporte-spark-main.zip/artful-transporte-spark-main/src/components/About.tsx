import { Building2, FileText, MapPin } from "lucide-react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import fachadaImg from "@/assets/photo-1.jpg";

const About = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="sobre" className="py-24 relative">
      <div className="absolute inset-0 bg-secondary/30" />
      <div ref={ref} className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <span className="text-accent font-heading font-semibold text-sm tracking-[0.2em] uppercase">Quem Somos</span>
          <h2 className="text-3xl md:text-4xl font-heading font-bold mt-3">
            Sobre a <span className="text-gradient-brand">Stark Lar</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Photo */}
          <div className={`transition-all duration-700 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"}`}>
            <div className="rounded-2xl overflow-hidden border border-border shadow-2xl shadow-primary/10">
              <img
                src={fachadaImg}
                alt="Fachada da Stark Lar Transportes — Distribuição & Logística em Jaguaruna, SC"
                className="w-full h-auto object-cover"
                loading="lazy"
              />
            </div>
          </div>

          {/* Text */}
          <div className={`transition-all duration-700 delay-200 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"}`}>
            <p className="text-muted-foreground leading-relaxed mb-6">
              Atuamos com foco em distribuição, transporte e logística de ferragens e plásticos,
              oferecendo suporte operacional, agilidade no atendimento e organização administrativa
              para parceiros comerciais em todo o Brasil.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Desde nossa fundação em Jaguaruna - SC, construímos uma reputação sólida baseada
              na confiança, pontualidade e excelência operacional, atendendo indústrias e distribuidores
              com compromisso e segurança.
            </p>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <FileText className="w-5 h-5 text-accent mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium">CNPJ</p>
                  <p className="text-sm text-muted-foreground">26.731.236/0001-58</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Building2 className="w-5 h-5 text-accent mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium">Inscrição Estadual</p>
                  <p className="text-sm text-muted-foreground">258.789.819</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-accent mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium">Endereço</p>
                  <p className="text-sm text-muted-foreground">Rodovia JAU 508, s/n — Olho D'Água, Jaguaruna - SC</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
