import { Truck, Package, Zap, ShieldCheck, Globe, Wrench } from "lucide-react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import servicesBg from "@/assets/services-bg.jpg";

const services = [
  { icon: Truck, title: "Transporte Rodoviário", desc: "Frota própria e rastreada para entregas seguras em todo o Brasil com agilidade e pontualidade." },
  { icon: Package, title: "Logística Integrada", desc: "Gestão completa da cadeia logística, do armazenamento à entrega final com eficiência operacional." },
  { icon: Zap, title: "Entregas Expressas", desc: "Serviço de entrega rápida para demandas urgentes com prioridade e rastreamento em tempo real." },
  { icon: ShieldCheck, title: "Cargas Especiais", desc: "Transporte especializado para cargas que exigem cuidados específicos de manuseio e segurança." },
  { icon: Globe, title: "Distribuição Nacional", desc: "Rede de distribuição abrangente com cobertura em todas as regiões do país." },
  { icon: Wrench, title: "Ferragens & Plásticos", desc: "Distribuição especializada de ferragens e plásticos para indústria e comércio." },
];

const Services = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="servicos" className="py-24 relative overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img src={servicesBg} alt="" className="w-full h-full object-cover opacity-5" loading="lazy" width={1920} height={1080} />
        <div className="absolute inset-0 bg-secondary/50" />
      </div>

      <div ref={ref} className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <span className={`text-accent font-heading font-semibold text-sm tracking-[0.2em] uppercase transition-all duration-500 ${isVisible ? "opacity-100" : "opacity-0"}`}>
            O Que Fazemos
          </span>
          <h2 className={`text-3xl md:text-4xl font-heading font-bold mt-3 transition-all duration-500 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}>
            Nossos <span className="text-gradient-brand">Serviços</span>
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map(({ icon: Icon, title, desc }, i) => (
            <div
              key={title}
              className={`group p-6 rounded-xl bg-card/80 border border-border backdrop-blur-md hover:border-primary/40 transition-all duration-500 hover:shadow-lg hover:shadow-primary/5 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: isVisible ? `${150 + i * 100}ms` : "0ms" }}
            >
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <Icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-heading font-semibold mb-2 group-hover:text-primary transition-colors">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
