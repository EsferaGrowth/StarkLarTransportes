import { Truck, Shield, Clock, MapPin, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { useCountUp } from "@/hooks/useCountUp";
import heroBg from "@/assets/hero-bg.jpg";
import heroTruck from "@/assets/hero-truck-2.jpg";
import heroLogistics from "@/assets/hero-logistics.jpg";

const stats = [
  { value: 15, suffix: "+", label: "Anos de Experiência" },
  { value: 50, suffix: "k+", label: "Entregas Realizadas" },
  { value: 98, suffix: "%", label: "Satisfação dos Clientes" },
];

const highlights = [
  { icon: Truck, text: "Frota Rastreada" },
  { icon: Shield, text: "Seguro Incluso" },
  { icon: Clock, text: "Pontualidade" },
];

const StatItem = ({ value, suffix, label, start }: { value: number; suffix: string; label: string; start: boolean }) => {
  const count = useCountUp(value, 2000, start);
  return (
    <div className="text-center">
      <p className="text-3xl md:text-4xl font-heading font-bold text-primary">
        {count}{suffix}
      </p>
      <p className="text-xs md:text-sm text-muted-foreground mt-1">{label}</p>
    </div>
  );
};

const Hero = () => {
  const { ref, isVisible } = useScrollAnimation(0.1);

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-background">
      {/* Subtle background pattern */}
      <div className="absolute top-1/4 -right-32 w-96 h-96 rounded-full bg-primary/5 blur-3xl" />
      <div className="absolute bottom-1/4 -left-32 w-80 h-80 rounded-full bg-accent/5 blur-3xl" />

      <div ref={ref} className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-12">
          {/* Left: Text content */}
          <div className={`transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-xs font-medium text-primary">Jaguaruna, SC — Atendemos todo o Brasil</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold leading-tight mb-6">
              Distribuição,{" "}
              <span className="text-gradient-gold">Transporte</span>{" "}
              <span className="text-primary">&</span> Logística
            </h1>

            <p className="text-lg text-muted-foreground max-w-xl mb-8 leading-relaxed">
              Ferragens e plásticos com agilidade e segurança em todo o Brasil.
              Suporte operacional e organização administrativa de excelência.
            </p>

            <div className="flex flex-col sm:flex-row items-start gap-4">
              <Button asChild size="lg" className="bg-gradient-gold text-white font-semibold text-base px-8 shadow-lg shadow-accent/25 hover:opacity-90">
                <a href="#contato">Solicitar Orçamento</a>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-primary/30 text-primary hover:bg-primary/10 font-semibold text-base px-8">
                <a href="https://wa.me/554836600313" target="_blank" rel="noopener noreferrer">
                  <Phone className="w-4 h-4 mr-2" />
                  (48) 3660-0313
                </a>
              </Button>
            </div>
          </div>

          {/* Right: Photo grid */}
          <div className={`transition-all duration-700 delay-200 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"}`}>
            <div className="grid grid-cols-2 gap-4">
              <div className="row-span-2 rounded-2xl overflow-hidden border border-border shadow-xl">
                <img src={heroBg} alt="Frota Stark Lar em rodovia" className="w-full h-full object-cover" width={1920} height={1080} />
              </div>
              <div className="rounded-2xl overflow-hidden border border-border shadow-xl">
                <img src={heroTruck} alt="Caminhão de entregas" className="w-full h-full object-cover" width={800} height={600} />
              </div>
              <div className="rounded-2xl overflow-hidden border border-border shadow-xl">
                <img src={heroLogistics} alt="Operação logística no galpão" className="w-full h-full object-cover" width={800} height={600} />
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className={`flex justify-center gap-8 md:gap-16 mb-12 transition-all duration-700 delay-300 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          {stats.map((s) => (
            <StatItem key={s.label} {...s} start={isVisible} />
          ))}
        </div>

        {/* Highlight cards */}
        <div className={`flex flex-wrap justify-center gap-4 transition-all duration-700 delay-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          {highlights.map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center gap-3 px-6 py-4 rounded-xl bg-card border border-border hover:border-primary/40 hover:shadow-md transition-all">
              <Icon className="w-5 h-5 text-accent" />
              <span className="text-sm font-medium">{text}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
