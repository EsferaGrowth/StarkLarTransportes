import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { Building2, Briefcase, Warehouse } from "lucide-react";
import escritorioImg from "@/assets/photo-2.jpg";
import galpaoImg from "@/assets/photo-3.jpg";
import lateralImg from "@/assets/photo-4.jpg";
import interiorImg from "@/assets/photo-5.jpg";

const photos = [
  { src: galpaoImg, alt: "Galpão de distribuição com empilhadeira", label: "Centro de Distribuição", icon: Warehouse },
  { src: interiorImg, alt: "Interior do galpão com ferragens e empilhadeira", label: "Área de Armazenamento", icon: Building2 },
  { src: escritorioImg, alt: "Escritório administrativo da Stark Lar", label: "Escritório Administrativo", icon: Briefcase },
  { src: lateralImg, alt: "Vista lateral do galpão e veículo da frota", label: "Estrutura & Frota", icon: Building2 },
];

const Structure = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section className="py-24">
      <div ref={ref} className="container mx-auto px-4">
        <div className="text-center mb-16">
          <span className={`text-accent font-heading font-semibold text-sm tracking-[0.2em] uppercase transition-all duration-500 ${isVisible ? "opacity-100" : "opacity-0"}`}>
            Nossa Infraestrutura
          </span>
          <h2 className={`text-3xl md:text-4xl font-heading font-bold mt-3 transition-all duration-500 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}>
            Estrutura <span className="text-gradient-brand">Completa</span>
          </h2>
          <p className={`text-muted-foreground mt-4 max-w-xl mx-auto transition-all duration-500 delay-200 ${isVisible ? "opacity-100" : "opacity-0"}`}>
            Galpão amplo, escritório moderno e empilhadeiras para operações ágeis de carga e descarga.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {photos.map(({ src, alt, label, icon: Icon }, i) => (
            <div
              key={label}
              className={`group relative rounded-xl overflow-hidden border border-border hover:border-primary/40 transition-all duration-500 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: isVisible ? `${200 + i * 120}ms` : "0ms" }}
            >
              <img
                src={src}
                alt={alt}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-5 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/20 backdrop-blur-sm flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <p className="font-heading font-semibold text-sm">{label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Structure;
