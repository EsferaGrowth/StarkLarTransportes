import { MessageCircle } from "lucide-react";

const WhatsAppButton = () => (
  <a
    href="https://wa.me/554836600313"
    target="_blank"
    rel="noopener noreferrer"
    className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-green-500 hover:bg-green-600 flex items-center justify-center shadow-lg shadow-green-500/30 transition-all hover:scale-110"
    aria-label="Fale no WhatsApp"
  >
    <MessageCircle className="w-7 h-7 text-white fill-white" />
  </a>
);

export default WhatsAppButton;
