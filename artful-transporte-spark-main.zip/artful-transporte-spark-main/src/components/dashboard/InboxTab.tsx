import { InboxList, InboxEmail, GeneratedTaskDraft } from "./InboxList";
import { EmailDetail } from "./EmailDetail";

interface InboxTabProps {
  emails: InboxEmail[];
  selectedEmail: InboxEmail | null;
  loading: boolean;
  onSelect: (email: InboxEmail) => void;
  onTaskGenerated: (draft: GeneratedTaskDraft) => void;
}

export const InboxTab = ({
  emails, selectedEmail, loading, onSelect, onTaskGenerated,
}: InboxTabProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-[400px_1fr] h-full border-t border-border">
      <div className="border-r border-border overflow-y-auto">
        <InboxList
          emails={emails}
          selectedId={selectedEmail?.id ?? null}
          onSelect={onSelect}
          onTaskGenerated={onTaskGenerated}
          loading={loading}
        />
      </div>
      <div className="overflow-hidden">
        <EmailDetail email={selectedEmail} />
      </div>
    </div>
  );
};
