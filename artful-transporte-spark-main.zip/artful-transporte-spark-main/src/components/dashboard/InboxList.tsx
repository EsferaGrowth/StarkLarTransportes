import { useState } from "react";
import { Mail, MailOpen, Sparkles, Loader2, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

export interface InboxEmail {
  id: string;
  message_id: string;
  from_email: string;
  from_name: string | null;
  subject: string;
  body_text: string | null;
  received_at: string;
  is_read: boolean;
  has_task: boolean;
}

interface InboxListProps {
  emails: InboxEmail[];
  selectedId: string | null;
  onSelect: (email: InboxEmail) => void;
  onTaskGenerated: (taskDraft: GeneratedTaskDraft) => void;
  loading: boolean;
}

export interface GeneratedTaskDraft {
  title: string;
  description: string;
  priority: "low" | "medium" | "high" | "urgent";
  suggested_column: string;
  source_email_id: string;
}

export const InboxList = ({ emails, selectedId, onSelect, onTaskGenerated, loading }: InboxListProps) => {
  const [generatingFor, setGeneratingFor] = useState<string | null>(null);

  const generateTask = async (email: InboxEmail) => {
    setGeneratingFor(email.id);
    try {
      const { data, error } = await supabase.functions.invoke("generate-task-from-email", {
        body: { email_id: email.id },
      });
      if (error) throw error;
      if (!data?.success) throw new Error(data?.error ?? "Erro ao gerar tarefa");
      onTaskGenerated(data.task);
      toast.success("Tarefa gerada pela IA — revise e salve.");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro ao gerar tarefa";
      toast.error(msg);
    } finally {
      setGeneratingFor(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground">
        <Loader2 className="w-5 h-5 animate-spin mr-2" /> Carregando...
      </div>
    );
  }

  if (emails.length === 0) {
    return (
      <div className="text-center py-16 text-muted-foreground">
        <Mail className="w-12 h-12 mx-auto mb-3 opacity-30" />
        <p className="text-sm">Nenhum e-mail na caixa de entrada.</p>
        <p className="text-xs mt-2">O microserviço IMAP envia e-mails novos a cada 5 minutos.</p>
      </div>
    );
  }

  return (
    <div className="divide-y divide-border">
      {emails.map((email) => {
        const isSelected = email.id === selectedId;
        const isGenerating = generatingFor === email.id;
        return (
          <button
            key={email.id}
            type="button"
            onClick={() => onSelect(email)}
            className={`w-full text-left p-4 hover:bg-accent/50 transition-colors ${
              isSelected ? "bg-accent" : ""
            } ${!email.is_read ? "border-l-2 border-l-primary" : ""}`}
          >
            <div className="flex items-start gap-3">
              <div className="mt-1">
                {email.is_read ? (
                  <MailOpen className="w-4 h-4 text-muted-foreground" />
                ) : (
                  <Mail className="w-4 h-4 text-primary" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline justify-between gap-2">
                  <p className={`text-sm truncate ${!email.is_read ? "font-semibold" : ""}`}>
                    {email.from_name || email.from_email}
                  </p>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    {formatDistanceToNow(new Date(email.received_at), { locale: ptBR, addSuffix: false })}
                  </span>
                </div>
                <p className={`text-sm truncate mt-0.5 ${!email.is_read ? "font-medium" : ""}`}>
                  {email.subject}
                </p>
                <p className="text-xs text-muted-foreground truncate mt-1">
                  {email.body_text?.slice(0, 100)}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  {email.has_task && (
                    <span className="text-xs px-2 py-0.5 rounded bg-primary/10 text-primary">
                      Tarefa criada
                    </span>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 text-xs"
                    disabled={isGenerating}
                    onClick={(e) => {
                      e.stopPropagation();
                      generateTask(email);
                    }}
                  >
                    {isGenerating ? (
                      <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                    ) : (
                      <Sparkles className="w-3 h-3 mr-1" />
                    )}
                    Gerar tarefa com IA
                  </Button>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground mt-1" />
            </div>
          </button>
        );
      })}
    </div>
  );
};
