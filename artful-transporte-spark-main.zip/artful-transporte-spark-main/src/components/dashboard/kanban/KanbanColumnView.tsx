import { useDroppable } from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TaskCard } from "./TaskCard";
import { KanbanColumn, KanbanTask } from "./types";

interface KanbanColumnViewProps {
  column: KanbanColumn;
  tasks: KanbanTask[];
  currentUserId: string;
  isAdmin: boolean;
  onDelete: (id: string) => void;
  onAddTask: (columnId: string) => void;
}

export const KanbanColumnView = ({
  column, tasks, currentUserId, isAdmin, onDelete, onAddTask,
}: KanbanColumnViewProps) => {
  const { setNodeRef, isOver } = useDroppable({ id: column.id });

  return (
    <div className="flex flex-col bg-muted/30 rounded-lg w-72 flex-shrink-0 max-h-full">
      <div className="p-3 flex items-center justify-between border-b border-border">
        <div className="flex items-center gap-2">
          <span
            className="w-2 h-2 rounded-full"
            style={{ backgroundColor: `hsl(${column.color})` }}
          />
          <h3 className="text-sm font-semibold">{column.name}</h3>
          <span className="text-xs text-muted-foreground">{tasks.length}</span>
        </div>
        <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => onAddTask(column.id)}>
          <Plus className="w-4 h-4" />
        </Button>
      </div>
      <div
        ref={setNodeRef}
        className={`flex-1 overflow-y-auto p-2 space-y-2 min-h-32 transition-colors ${
          isOver ? "bg-primary/5" : ""
        }`}
      >
        <SortableContext items={tasks.map((t) => t.id)} strategy={verticalListSortingStrategy}>
          {tasks.map((task) => (
            <TaskCard
              key={task.id}
              task={task}
              currentUserId={currentUserId}
              isAdmin={isAdmin}
              onDelete={onDelete}
            />
          ))}
        </SortableContext>
        {tasks.length === 0 && (
          <p className="text-xs text-muted-foreground text-center py-6">Sem tarefas</p>
        )}
      </div>
    </div>
  );
};
