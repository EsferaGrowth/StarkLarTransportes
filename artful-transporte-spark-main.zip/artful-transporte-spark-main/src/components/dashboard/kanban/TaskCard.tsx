import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical, Sparkles, Trash2 } from "lucide-react";
import { KanbanTask, priorityColors, priorityLabel } from "./types";

interface TaskCardProps {
  task: KanbanTask;
  currentUserId: string;
  isAdmin: boolean;
  onDelete: (id: string) => void;
}

export const TaskCard = ({ task, currentUserId, isAdmin, onDelete }: TaskCardProps) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: task.id,
  });

  const canDelete = isAdmin || task.created_by === currentUserId;

  return (
    <div
      ref={setNodeRef}
      style={{
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.4 : 1,
      }}
      className="bg-card border border-border rounded-lg p-3 shadow-sm hover:shadow-md transition-shadow group"
    >
      <div className="flex items-start gap-2">
        <button
          {...attributes}
          {...listeners}
          className="text-muted-foreground hover:text-foreground cursor-grab active:cursor-grabbing mt-0.5"
        >
          <GripVertical className="w-4 h-4" />
        </button>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h4 className="text-sm font-medium leading-snug break-words">{task.title}</h4>
            {canDelete && (
              <button
                type="button"
                onClick={() => onDelete(task.id)}
                className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-opacity"
                aria-label="Apagar tarefa"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          {task.description && (
            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{task.description}</p>
          )}
          <div className="flex items-center gap-1.5 mt-2 flex-wrap">
            <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${priorityColors[task.priority]}`}>
              {priorityLabel[task.priority]}
            </span>
            {task.ai_generated && (
              <span className="text-[10px] px-1.5 py-0.5 rounded font-medium bg-primary/10 text-primary inline-flex items-center gap-0.5">
                <Sparkles className="w-2.5 h-2.5" /> IA
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
