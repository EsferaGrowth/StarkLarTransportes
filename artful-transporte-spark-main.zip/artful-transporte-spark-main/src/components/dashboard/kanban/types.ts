export interface KanbanColumn {
  id: string;
  name: string;
  position: number;
  color: string;
}

export interface KanbanTask {
  id: string;
  title: string;
  description: string | null;
  priority: "low" | "medium" | "high" | "urgent";
  column_id: string;
  position: number;
  created_by: string;
  source_email_id: string | null;
  ai_generated: boolean;
}

export const priorityColors: Record<KanbanTask["priority"], string> = {
  low: "bg-muted text-muted-foreground",
  medium: "bg-blue-500/10 text-blue-700 dark:text-blue-300",
  high: "bg-orange-500/10 text-orange-700 dark:text-orange-300",
  urgent: "bg-red-500/10 text-red-700 dark:text-red-300",
};

export const priorityLabel: Record<KanbanTask["priority"], string> = {
  low: "Baixa",
  medium: "Média",
  high: "Alta",
  urgent: "Urgente",
};
