import { InboxEmail } from "./InboxList";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Mail } from "lucide-react";

interface EmailDetailProps {
  email: InboxEmail | null;
}

export const EmailDetail = ({ email }: EmailDetailProps) => {
  if (!email) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <Mail className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="text-sm">Selecione um e-mail para visualizar.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 overflow-y-auto h-full">
      <h2 className="text-xl font-bold mb-2 break-words">{email.subject}</h2>
      <div className="flex items-center justify-between text-sm text-muted-foreground mb-4 pb-4 border-b border-border">
        <div>
          <p className="font-medium text-foreground">{email.from_name || email.from_email}</p>
          {email.from_name && <p className="text-xs">{email.from_email}</p>}
        </div>
        <span className="text-xs">
          {format(new Date(email.received_at), "dd 'de' MMM 'às' HH:mm", { locale: ptBR })}
        </span>
      </div>
      <div className="prose prose-sm max-w-none text-foreground whitespace-pre-wrap break-words">
        {email.body_text || "(e-mail sem conteúdo de texto)"}
      </div>
    </div>
  );
};
