import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import logoImg from "@/assets/logo-starklar-transparent.png";

interface DashboardHeaderProps {
  email: string | undefined;
  isAdmin: boolean;
}

export const DashboardHeader = ({ email, isAdmin }: DashboardHeaderProps) => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/app/login");
  };

  return (
    <header className="border-b border-border bg-card">
      <div className="px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={logoImg} alt="Stark Lar" className="h-8 w-auto" />
          <div>
            <p className="text-sm font-semibold">Painel de Gestão</p>
            <p className="text-xs text-muted-foreground">
              {email} {isAdmin && <span className="text-primary">(admin)</span>}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {isAdmin && (
            <Button variant="outline" size="sm" onClick={() => navigate("/admin/dashboard")}>
              Admin
            </Button>
          )}
          <Button variant="ghost" size="sm" onClick={handleLogout}>
            <LogOut className="w-4 h-4 mr-1" /> Sair
          </Button>
        </div>
      </div>
    </header>
  );
};
