import { useEffect, useState } from "react";
import {
  DndContext, DragEndEvent, DragOverlay, DragStartEvent,
  PointerSensor, useSensor, useSensors,
} from "@dnd-kit/core";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { KanbanColumnView } from "./kanban/KanbanColumnView";
import { KanbanColumn, KanbanTask } from "./kanban/types";

export type { KanbanColumn, KanbanTask } from "./kanban/types";

interface KanbanBoardProps {
  columns: KanbanColumn[];
  tasks: KanbanTask[];
  currentUserId: string;
  isAdmin: boolean;
  onTasksChange: () => void;
  onAddTask: (columnId: string) => void;
}

export const KanbanBoard = ({
  columns, tasks, currentUserId, isAdmin, onTasksChange, onAddTask,
}: KanbanBoardProps) => {
  const [activeTask, setActiveTask] = useState<KanbanTask | null>(null);
  const [localTasks, setLocalTasks] = useState<KanbanTask[]>(tasks);

  useEffect(() => setLocalTasks(tasks), [tasks]);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  const handleDragStart = (e: DragStartEvent) => {
    const task = localTasks.find((t) => t.id === e.active.id);
    if (task) setActiveTask(task);
  };

  const handleDragEnd = async (e: DragEndEvent) => {
    setActiveTask(null);
    const { active, over } = e;
    if (!over) return;

    const activeId = active.id as string;
    const overId = over.id as string;

    const draggedTask = localTasks.find((t) => t.id === activeId);
    if (!draggedTask) return;

    const overColumn = columns.find((c) => c.id === overId);
    const overTask = localTasks.find((t) => t.id === overId);
    const targetColumnId = overColumn ? overColumn.id : overTask?.column_id;
    if (!targetColumnId) return;

    if (draggedTask.column_id === targetColumnId && activeId === overId) return;

    const previous = localTasks;
    const next = localTasks.map((t) =>
      t.id === activeId ? { ...t, column_id: targetColumnId } : t,
    );
    setLocalTasks(next);

    const { error } = await supabase
      .from("kanban_tasks")
      .update({ column_id: targetColumnId })
      .eq("id", activeId);

    if (error) {
      toast.error("Erro ao mover tarefa");
      setLocalTasks(previous);
    } else {
      onTasksChange();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Apagar esta tarefa?")) return;
    const { error } = await supabase.from("kanban_tasks").delete().eq("id", id);
    if (error) {
      toast.error("Erro ao apagar");
    } else {
      toast.success("Tarefa apagada");
      onTasksChange();
    }
  };

  return (
    <DndContext sensors={sensors} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
      <div className="flex gap-3 overflow-x-auto p-4 h-full">
        {columns.map((col) => (
          <KanbanColumnView
            key={col.id}
            column={col}
            tasks={localTasks.filter((t) => t.column_id === col.id)}
            currentUserId={currentUserId}
            isAdmin={isAdmin}
            onDelete={handleDelete}
            onAddTask={onAddTask}
          />
        ))}
      </div>
      <DragOverlay>
        {activeTask && (
          <div className="bg-card border border-border rounded-lg p-3 shadow-lg w-64">
            <h4 className="text-sm font-medium">{activeTask.title}</h4>
          </div>
        )}
      </DragOverlay>
    </DndContext>
  );
};
