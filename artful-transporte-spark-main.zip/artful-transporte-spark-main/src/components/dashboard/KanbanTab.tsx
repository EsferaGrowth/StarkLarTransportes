import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { KanbanBoard, KanbanColumn, KanbanTask } from "./KanbanBoard";

interface KanbanTabProps {
  columns: KanbanColumn[];
  tasks: KanbanTask[];
  currentUserId: string;
  isAdmin: boolean;
  onTasksChange: () => void;
  onAddTask: (columnId: string) => void;
}

export const KanbanTab = ({
  columns, tasks, currentUserId, isAdmin, onTasksChange, onAddTask,
}: KanbanTabProps) => {
  return (
    <div className="border-t border-border h-full flex flex-col">
      <div className="px-4 py-2 flex justify-end">
        <Button size="sm" onClick={() => onAddTask(columns[0]?.id ?? "")}>
          <Plus className="w-4 h-4 mr-1" /> Nova tarefa
        </Button>
      </div>
      <div className="flex-1 overflow-hidden">
        <KanbanBoard
          columns={columns}
          tasks={tasks}
          currentUserId={currentUserId}
          isAdmin={isAdmin}
          onTasksChange={onTasksChange}
          onAddTask={onAddTask}
        />
      </div>
    </div>
  );
};
