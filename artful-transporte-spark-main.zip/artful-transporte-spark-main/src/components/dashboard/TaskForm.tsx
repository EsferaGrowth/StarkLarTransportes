import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import { GeneratedTaskDraft } from "./InboxList";
import type { KanbanColumn } from "./KanbanBoard";

interface TaskFormProps {
  open: boolean;
  onClose: () => void;
  onSave: (data: {
    title: string;
    description: string;
    priority: "low" | "medium" | "high" | "urgent";
    column_id: string;
    source_email_id?: string | null;
    ai_generated: boolean;
  }) => Promise<void>;
  columns: KanbanColumn[];
  initialColumnId?: string;
  draft?: GeneratedTaskDraft | null;
}

export const TaskForm = ({ open, onClose, onSave, columns, initialColumnId, draft }: TaskFormProps) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState<"low" | "medium" | "high" | "urgent">("medium");
  const [columnId, setColumnId] = useState<string>("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      if (draft) {
        setTitle(draft.title);
        setDescription(draft.description);
        setPriority(draft.priority);
        const matchCol = columns.find((c) => c.name === draft.suggested_column);
        setColumnId(matchCol?.id ?? initialColumnId ?? columns[0]?.id ?? "");
      } else {
        setTitle("");
        setDescription("");
        setPriority("medium");
        setColumnId(initialColumnId ?? columns[0]?.id ?? "");
      }
    }
  }, [open, draft, initialColumnId, columns]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !columnId) return;
    setSaving(true);
    try {
      await onSave({
        title: title.trim().slice(0, 200),
        description: description.trim().slice(0, 5000),
        priority,
        column_id: columnId,
        source_email_id: draft?.source_email_id ?? null,
        ai_generated: !!draft,
      });
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {draft && <Sparkles className="w-4 h-4 text-primary" />}
            {draft ? "Tarefa gerada pela IA" : "Nova tarefa"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1 block">Título</label>
            <input
              required
              maxLength={200}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-md bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block">Descrição</label>
            <textarea
              maxLength={5000}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={5}
              className="w-full px-3 py-2 rounded-md bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 resize-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium mb-1 block">Prioridade</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as typeof priority)}
                className="w-full px-3 py-2 rounded-md bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
              >
                <option value="low">Baixa</option>
                <option value="medium">Média</option>
                <option value="high">Alta</option>
                <option value="urgent">Urgente</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Coluna</label>
              <select
                value={columnId}
                onChange={(e) => setColumnId(e.target.value)}
                className="w-full px-3 py-2 rounded-md bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
              >
                {columns.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit" disabled={saving} className="bg-gradient-brand text-white">
              {saving ? "Salvando..." : "Salvar tarefa"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
