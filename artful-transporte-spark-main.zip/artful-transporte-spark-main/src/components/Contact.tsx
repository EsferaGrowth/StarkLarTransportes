import { Phone, Mail, MapPin, Clock, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const contactInfo = [
  { icon: Phone, label: "Telefone", value: "(48) 3660-0313", href: "tel:+554836600313" },
  { icon: Mail, label: "Comercial", value: "comercial@starklartransportes.com.br", href: "mailto:comercial@starklartransportes.com.br" },
  { icon: Mail, label: "Financeiro", value: "financeiro@starklartransportes.com.br", href: "mailto:financeiro@starklartransportes.com.br" },
  { icon: Mail, label: "NF-e", value: "nfe@starklartransportes.com.br", href: "mailto:nfe@starklartransportes.com.br" },
  { icon: MapPin, label: "Endereço", value: "Rod. JAU 508, s/n — Olho D'Água, Jaguaruna - SC" },
  { icon: Clock, label: "Horário", value: "Seg a Sex — 08h às 18h" },
];

const Contact = () => {
  const { ref, isVisible } = useScrollAnimation();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!form.name.trim() || !form.email.trim() || !form.message.trim()) {
      toast.error("Preencha os campos obrigatórios.");
      return;
    }

    if (form.name.length > 100 || form.email.length > 255 || form.message.length > 2000) {
      toast.error("Algum campo excede o limite de caracteres.");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(form.email.trim())) {
      toast.error("Informe um email válido.");
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from("contact_messages").insert({
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim() || null,
        message: form.message.trim(),
      });

      if (error) throw error;

      // Build WhatsApp message
      const text = encodeURIComponent(
        `*Nova mensagem do site*\n\n` +
        `*Nome:* ${form.name.trim()}\n` +
        `*Email:* ${form.email.trim()}\n` +
        `*Telefone:* ${form.phone.trim() || "Não informado"}\n` +
        `*Mensagem:* ${form.message.trim()}`
      );
      window.open(`https://wa.me/554836600313?text=${text}`, "_blank");

      toast.success("Mensagem enviada com sucesso!");
      setForm({ name: "", email: "", phone: "", message: "" });
    } catch {
      toast.error("Erro ao enviar mensagem. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="contato" className="py-24 relative">
      <div className="absolute inset-0 bg-secondary/30" />
      <div ref={ref} className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <span className="text-accent font-heading font-semibold text-sm tracking-[0.2em] uppercase">Fale Conosco</span>
          <h2 className="text-3xl md:text-4xl font-heading font-bold mt-3">
            Entre em <span className="text-gradient-brand">Contato</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Contact info */}
          <div className={`space-y-4 transition-all duration-700 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"}`}>
            {contactInfo.map(({ icon: Icon, label, value, href }) => (
              <div key={label} className="flex items-start gap-4 p-4 rounded-xl bg-card border border-border">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">{label}</p>
                  {href ? (
                    <a href={href} className="text-sm font-medium hover:text-primary transition-colors break-all">{value}</a>
                  ) : (
                    <p className="text-sm font-medium">{value}</p>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Contact form */}
          <form onSubmit={handleSubmit} className={`space-y-4 transition-all duration-700 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <div>
              <label htmlFor="name" className="text-sm font-medium mb-1 block">Nome *</label>
              <input
                id="name"
                type="text"
                maxLength={100}
                required
                value={form.name}
                onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))}
                className="w-full px-4 py-3 rounded-lg bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all text-sm"
                placeholder="Seu nome completo"
              />
            </div>
            <div>
              <label htmlFor="email" className="text-sm font-medium mb-1 block">Email *</label>
              <input
                id="email"
                type="email"
                maxLength={255}
                required
                value={form.email}
                onChange={(e) => setForm(f => ({ ...f, email: e.target.value }))}
                className="w-full px-4 py-3 rounded-lg bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all text-sm"
                placeholder="seu@email.com"
              />
            </div>
            <div>
              <label htmlFor="phone" className="text-sm font-medium mb-1 block">Telefone</label>
              <input
                id="phone"
                type="tel"
                maxLength={20}
                value={form.phone}
                onChange={(e) => setForm(f => ({ ...f, phone: e.target.value }))}
                className="w-full px-4 py-3 rounded-lg bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all text-sm"
                placeholder="(48) 99999-9999"
              />
            </div>
            <div>
              <label htmlFor="message" className="text-sm font-medium mb-1 block">Mensagem *</label>
              <textarea
                id="message"
                maxLength={2000}
                required
                rows={4}
                value={form.message}
                onChange={(e) => setForm(f => ({ ...f, message: e.target.value }))}
                className="w-full px-4 py-3 rounded-lg bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all text-sm resize-none"
                placeholder="Como podemos ajudá-lo?"
              />
            </div>
            <Button type="submit" disabled={loading} size="lg" className="w-full bg-gradient-gold text-white font-semibold hover:opacity-90">
              <Send className="w-4 h-4 mr-2" />
              {loading ? "Enviando..." : "Enviar e abrir WhatsApp"}
            </Button>
          </form>

          {/* Map */}
          <div className={`rounded-xl overflow-hidden border border-border min-h-[400px] transition-all duration-700 delay-200 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"}`}>
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3512.5!2d-49.03!3d-28.61!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zJaguaruna+-+SC!5e0!3m2!1spt-BR!2sbr"
              width="100%" height="100%" style={{ border: 0, minHeight: 400 }}
              allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade"
              title="Localização Stark Lar Transportes"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
