import { Truck, Radar, Users, ShieldCheck } from "lucide-react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const items = [
  { icon: Truck, title: "Frota Moderna", desc: "Veículos modernos e bem mantidos para garantir segurança e eficiência em cada transporte." },
  { icon: Radar, title: "Rastreamento 24/7", desc: "Monitoramento em tempo real de todas as cargas com tecnologia GPS de última geração." },
  { icon: Users, title: "Equipe Qualificada", desc: "Profissionais treinados e comprometidos com a excelência no atendimento e operação." },
  { icon: ShieldCheck, title: "Seguro Completo", desc: "Todas as cargas são asseguradas, proporcionando tranquilidade total aos nossos clientes." },
];

const Differentials = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="diferenciais" className="py-24 relative">
      <div className="absolute inset-0 bg-secondary/30" />
      <div ref={ref} className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <span className="text-accent font-heading font-semibold text-sm tracking-[0.2em] uppercase">Por Que Nos Escolher</span>
          <h2 className="text-3xl md:text-4xl font-heading font-bold mt-3">
            Nossos <span className="text-gradient-brand">Diferenciais</span>
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map(({ icon: Icon, title, desc }, i) => (
            <div
              key={title}
              className={`text-center p-8 rounded-xl bg-card/50 border border-border backdrop-blur-sm hover:border-primary/40 transition-all duration-500 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: isVisible ? `${i * 120}ms` : "0ms" }}
            >
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-5">
                <Icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-heading font-semibold mb-3">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Differentials;
