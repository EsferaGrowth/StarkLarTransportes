import logoImg from "@/assets/logo-starklar-transparent.png";

const footerLinks = [
  { href: "#servicos", label: "Serviços" },
  { href: "#sobre", label: "Sobre" },
  { href: "#diferenciais", label: "Diferenciais" },
  { href: "#parceiros", label: "Parceiros" },
  { href: "#contato", label: "Contato" },
];

const Footer = () => {
  return (
    <footer className="bg-[hsl(220_25%_10%)] text-white border-t border-border py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <a href="#">
            <img src={logoImg} alt="Stark Lar Transportes" className="h-10 w-auto" />
          </a>
          <nav className="flex flex-wrap justify-center gap-6">
            {footerLinks.map((link) => (
              <a key={link.href} href={link.href} className="text-sm text-white/60 hover:text-white transition-colors">
                {link.label}
              </a>
            ))}
          </nav>
        </div>
        <div className="mt-8 pt-8 border-t border-white/10 text-center space-y-2">
          <p className="text-xs text-white/50">CNPJ: 26.731.236/0001-58 — Rod. JAU 508, s/n — Olho D'Água, Jaguaruna - SC</p>
          <p className="text-xs text-white/50">© {new Date().getFullYear()} Stark Lar Transportes. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
