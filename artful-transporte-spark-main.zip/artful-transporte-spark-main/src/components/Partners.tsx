import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { Building } from "lucide-react";

const partners = [
  "S&S Indústria", "ACX Metais", "DFP Forros",
  "CPX Distribuidora", "Elimaq", "Aços Poconé",
];

const Partners = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="parceiros" className="py-24">
      <div ref={ref} className="container mx-auto px-4">
        <div className="text-center mb-16">
          <span className="text-accent font-heading font-semibold text-sm tracking-[0.2em] uppercase">Quem Confia em Nós</span>
          <h2 className="text-3xl md:text-4xl font-heading font-bold mt-3">
            Parceiros <span className="text-gradient-brand">Comerciais</span>
          </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
          {partners.map((name, i) => (
            <div
              key={name}
              className={`flex flex-col items-center justify-center gap-3 p-6 rounded-xl bg-card border border-border hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5 transition-all duration-500 group ${
                isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
              }`}
              style={{ transitionDelay: isVisible ? `${i * 80}ms` : "0ms" }}
            >
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                <Building className="w-5 h-5 text-accent" />
              </div>
              <p className="font-heading font-semibold text-sm text-center">{name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Partners;
