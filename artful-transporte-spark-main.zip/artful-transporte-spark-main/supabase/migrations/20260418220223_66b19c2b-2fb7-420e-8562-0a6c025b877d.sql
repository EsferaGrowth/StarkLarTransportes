
-- INBOX EMAILS
CREATE TABLE public.inbox_emails (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id TEXT NOT NULL UNIQUE,
  from_email TEXT NOT NULL,
  from_name TEXT,
  to_email TEXT,
  subject TEXT NOT NULL DEFAULT '(sem assunto)',
  body_text TEXT,
  body_html TEXT,
  received_at TIMESTAMPTZ NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT false,
  has_task BOOLEAN NOT NULL DEFAULT false,
  raw_headers JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_inbox_emails_received_at ON public.inbox_emails (received_at DESC);
CREATE INDEX idx_inbox_emails_is_read ON public.inbox_emails (is_read) WHERE is_read = false;
ALTER TABLE public.inbox_emails ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view emails"
  ON public.inbox_emails FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'member'::app_role));

CREATE POLICY "Authenticated users can update emails"
  ON public.inbox_emails FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'member'::app_role));

-- KANBAN COLUMNS
CREATE TABLE public.kanban_columns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  position INTEGER NOT NULL,
  color TEXT NOT NULL DEFAULT '215 25% 27%',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.kanban_columns ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view columns"
  ON public.kanban_columns FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'member'::app_role));

CREATE POLICY "Admins can manage columns"
  ON public.kanban_columns FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

INSERT INTO public.kanban_columns (name, position, color) VALUES
  ('Backlog', 0, '215 25% 27%'),
  ('A Fazer', 1, '217 91% 60%'),
  ('Em Andamento', 2, '38 92% 50%'),
  ('Revisão', 3, '271 91% 65%'),
  ('Concluído', 4, '142 71% 45%');

-- KANBAN TASKS
CREATE TABLE public.kanban_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low','medium','high','urgent')),
  column_id UUID NOT NULL REFERENCES public.kanban_columns(id) ON DELETE RESTRICT,
  position INTEGER NOT NULL DEFAULT 0,
  assigned_to UUID,
  created_by UUID NOT NULL,
  source_email_id UUID REFERENCES public.inbox_emails(id) ON DELETE SET NULL,
  ai_generated BOOLEAN NOT NULL DEFAULT false,
  due_date TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_kanban_tasks_column ON public.kanban_tasks (column_id, position);
CREATE INDEX idx_kanban_tasks_assigned ON public.kanban_tasks (assigned_to);
ALTER TABLE public.kanban_tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view tasks"
  ON public.kanban_tasks FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'member'::app_role));

CREATE POLICY "Authenticated users can create tasks"
  ON public.kanban_tasks FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = created_by
    AND (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'member'::app_role))
  );

CREATE POLICY "Authenticated users can update tasks"
  ON public.kanban_tasks FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'member'::app_role));

CREATE POLICY "Creators or admins can delete tasks"
  ON public.kanban_tasks FOR DELETE TO authenticated
  USING (auth.uid() = created_by OR public.has_role(auth.uid(), 'admin'::app_role));

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER set_kanban_tasks_updated_at
BEFORE UPDATE ON public.kanban_tasks
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- USER INVITATIONS
CREATE TABLE public.user_invitations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL,
  token TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex'),
  role app_role NOT NULL DEFAULT 'member',
  invited_by UUID NOT NULL,
  used BOOLEAN NOT NULL DEFAULT false,
  used_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '7 days'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_invitations_token ON public.user_invitations (token);
CREATE INDEX idx_invitations_email ON public.user_invitations (email);
ALTER TABLE public.user_invitations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view invitations"
  ON public.user_invitations FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can insert invitations"
  ON public.user_invitations FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role) AND auth.uid() = invited_by);

CREATE POLICY "Admins can update invitations"
  ON public.user_invitations FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete invitations"
  ON public.user_invitations FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role));
