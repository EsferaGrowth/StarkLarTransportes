-- Block privilege escalation on user_roles
-- Only service_role (used by accept-invite edge function) can write to this table

CREATE POLICY "Block all inserts from clients"
ON public.user_roles
FOR INSERT
TO authenticated, anon
WITH CHECK (false);

CREATE POLICY "Block all updates from clients"
ON public.user_roles
FOR UPDATE
TO authenticated, anon
USING (false);

CREATE POLICY "Block all deletes from clients"
ON public.user_roles
FOR DELETE
TO authenticated, anon
USING (false);