// Public endpoint: validates token + creates user account + grants member role.
// Body: { token, password, full_name? }
// Email is taken from the invitation (cannot be tampered with).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const body = await req.json();
    const token = String(body.token ?? "").trim();
    const password = String(body.password ?? "");

    if (!token || token.length !== 64) {
      return new Response(JSON.stringify({ error: "Token inválido" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!password || password.length < 8 || password.length > 128) {
      return new Response(JSON.stringify({ error: "Senha deve ter entre 8 e 128 caracteres" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: invite, error: invErr } = await admin
      .from("user_invitations")
      .select("id, email, role, used, expires_at")
      .eq("token", token)
      .maybeSingle();

    if (invErr || !invite) {
      return new Response(JSON.stringify({ error: "Convite não encontrado" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (invite.used) {
      return new Response(JSON.stringify({ error: "Convite já utilizado" }), {
        status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (new Date(invite.expires_at) < new Date()) {
      return new Response(JSON.stringify({ error: "Convite expirado" }), {
        status: 410, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Create user (auto-confirm email)
    const { data: created, error: createErr } = await admin.auth.admin.createUser({
      email: invite.email,
      password,
      email_confirm: true,
    });

    if (createErr || !created.user) {
      console.error("createUser error:", createErr);
      return new Response(JSON.stringify({ error: createErr?.message ?? "Erro ao criar usuário" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Grant role
    const { error: roleErr } = await admin
      .from("user_roles")
      .insert({ user_id: created.user.id, role: invite.role });

    if (roleErr) {
      console.error("role insert error:", roleErr);
      return new Response(JSON.stringify({ error: "Erro ao atribuir papel" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Mark invite used
    await admin
      .from("user_invitations")
      .update({ used: true, used_at: new Date().toISOString() })
      .eq("id", invite.id);

    return new Response(JSON.stringify({
      success: true,
      email: invite.email,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error("accept-invite error:", e);
    const msg = e instanceof Error ? e.message : "Unknown error";
    return new Response(JSON.stringify({ error: msg }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
