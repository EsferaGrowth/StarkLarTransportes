// Receives e-mails pushed by the external IMAP microservice (Railway/Render).
// Authenticates via shared IMAP_WEBHOOK_SECRET header. Inserts into inbox_emails,
// deduping by message_id.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-webhook-secret",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

interface IncomingEmail {
  message_id: string;
  from_email: string;
  from_name?: string;
  to_email?: string;
  subject?: string;
  body_text?: string;
  body_html?: string;
  received_at: string; // ISO
  raw_headers?: Record<string, unknown>;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const expectedSecret = Deno.env.get("IMAP_WEBHOOK_SECRET");
  const providedSecret = req.headers.get("x-webhook-secret");

  if (!expectedSecret) {
    console.error("IMAP_WEBHOOK_SECRET not configured");
    return new Response(JSON.stringify({ error: "Server misconfigured" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (!providedSecret || providedSecret !== expectedSecret) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  let payload: { emails?: IncomingEmail[] } | IncomingEmail;
  try {
    payload = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const list: IncomingEmail[] = Array.isArray((payload as any).emails)
    ? (payload as any).emails
    : [payload as IncomingEmail];

  // Basic validation
  const valid = list.filter((e) =>
    e &&
    typeof e.message_id === "string" && e.message_id.length > 0 && e.message_id.length < 1000 &&
    typeof e.from_email === "string" && e.from_email.length < 500 &&
    typeof e.received_at === "string"
  ).map((e) => ({
    message_id: e.message_id,
    from_email: e.from_email.slice(0, 500),
    from_name: e.from_name?.slice(0, 500) ?? null,
    to_email: e.to_email?.slice(0, 500) ?? null,
    subject: (e.subject ?? "(sem assunto)").slice(0, 998),
    body_text: e.body_text?.slice(0, 100000) ?? null,
    body_html: e.body_html?.slice(0, 200000) ?? null,
    received_at: e.received_at,
    raw_headers: e.raw_headers ?? null,
  }));

  if (valid.length === 0) {
    return new Response(JSON.stringify({ inserted: 0, skipped: 0 }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const { data, error } = await supabase
    .from("inbox_emails")
    .upsert(valid, { onConflict: "message_id", ignoreDuplicates: true })
    .select("id");

  if (error) {
    console.error("Insert error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response(
    JSON.stringify({ inserted: data?.length ?? 0, received: list.length }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } },
  );
});
